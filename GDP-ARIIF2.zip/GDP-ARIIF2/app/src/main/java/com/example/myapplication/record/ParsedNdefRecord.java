package com.example.myapplication.record;

public interface ParsedNdefRecord {

    String str();

}